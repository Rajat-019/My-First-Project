package edu.ccrm.exceptions;

public class DuplicateEnrollmentException extends Exception {
    public DuplicateEnrollmentException(String msg) { super(msg); }
}
